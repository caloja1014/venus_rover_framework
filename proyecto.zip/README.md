# Venus Rover Framework
Framework encargado de recibir información de sensores para su posterior análisis 
## Run
``
make & ./framework <puerto> -t frecuencia -x minutos-espera
``
## Debug
``
make debug ./framework <puerto> -t frecuencia -x minutos-espera -d
``
